# Kingmaker Swallowed Character Fix

## Description

This is a simple mod for Pathfinder: Kingmaker that provides a quick fix 
for a rare bug when the characters gets swallowed by a worm and is not 
spitted out after the worm is dead (usually happens with tiefling 
sisters).

## Installation

Installation

1. Download and install Unity Mod Manager
2. Download the mod
3. Extract the archive and put the mod folder into 'Mods' folder of the Game
4. Open the interface (Ctrl+f10)

## Usage

Just press the  'Unswallow' button. The game should be loaded and the 
character should be present in the party before usage (as is, you should swap
to the swallowed sister).

